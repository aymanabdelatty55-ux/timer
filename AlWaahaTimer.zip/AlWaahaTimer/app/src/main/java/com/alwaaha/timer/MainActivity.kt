package com.alwaaha.timer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF1B6B5A)
private val Red = Color(0xFFC62828)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TimerState.load(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green)) {
                Surface(modifier = Modifier.fillMaxSize()) { TimerScreen() }
            }
        }
    }
}

@Composable
fun TimerScreen() {
    val ctx = LocalContext.current
    val s = TimerState
    var needPermHint by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val progress = if (s.totalSec > 0) s.remainingMs / (s.totalSec * 1000f) else 0f
    val shownSec = (s.remainingMs + 999) / 1000
    val locked = s.running || s.ringing

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("تم") } },
                title = { Text("إعدادات التنبيهات") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("بيب في آخر 10 ثواني", modifier = Modifier.weight(1f))
                            Switch(checked = s.beepEnabled, onCheckedChange = { s.beepEnabled = it; s.save(ctx) })
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("تنبيه قبل النهاية", modifier = Modifier.weight(1f))
                            Switch(checked = s.warnEnabled, onCheckedChange = { s.warnEnabled = it; s.save(ctx) })
                        }
                        if (s.warnEnabled) {
                            Text("التنبيه قبل النهاية بـ:", fontSize = 13.sp, color = Color.Gray)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(1 to "دقيقة", 2 to "دقيقتين", 5 to "5 دقائق").forEach { (m, label) ->
                                    FilterChip(
                                        selected = s.warnMin == m,
                                        onClick = { s.warnMin = m; s.save(ctx) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }
                    }
                }
            )
        }
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "مؤقت الواحة", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green,
                    modifier = Modifier.align(Alignment.Center)
                )
                TextButton(
                    onClick = { showSettings = true },
                    modifier = Modifier.align(Alignment.CenterEnd),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("⚙ التنبيهات", fontSize = 13.sp) }
            }

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(260.dp)) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    strokeWidth = 14.dp,
                    color = if (s.ringing) Red else Green,
                    trackColor = Green.copy(alpha = 0.15f)
                )
                Text(
                    TimerState.fmt(shownSec), fontSize = 54.sp, fontWeight = FontWeight.Bold,
                    color = if (s.ringing) Red else Color.Black
                )
            }

            if (s.ringing) {
                Button(
                    onClick = { TimerService.send(ctx, TimerService.ACTION_STOP_ALARM) },
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("إيقاف المنبّه", fontSize = 20.sp) }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 5, 10, 15, 30, 45, 60, 90).chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { m ->
                                FilterChip(
                                    selected = s.totalSec == m * 60L,
                                    onClick = { s.setTotal(m * 60L) },
                                    enabled = !locked,
                                    label = { Text(when (m) { 60 -> "ساعة"; 90 -> "ساعة ونصف"; else -> "$m دقيقة" }) }
                                )
                            }
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("− دقيقة" to -60L, "− 10 ث" to -10L, "+ 10 ث" to 10L, "+ دقيقة" to 60L).forEach { (label, d) ->
                            OutlinedButton(
                                onClick = { s.setTotal(s.totalSec + d) },
                                enabled = !locked,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 2.dp)
                            ) { Text(label, fontSize = 13.sp, maxLines = 1) }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { TimerService.send(ctx, TimerService.ACTION_TOGGLE) },
                        modifier = Modifier.weight(1f).height(56.dp)
                    ) { Text(if (s.running) "إيقاف مؤقت" else "ابدأ", fontSize = 20.sp) }
                    OutlinedButton(
                        onClick = {
                            if (s.running || s.ringing) TimerService.send(ctx, TimerService.ACTION_RESET)
                            else s.remainingMs = s.totalSec * 1000
                        },
                        modifier = Modifier.weight(1f).height(56.dp)
                    ) { Text("إعادة", fontSize = 20.sp) }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                OutlinedButton(
                    onClick = {
                        when {
                            s.overlayShown -> TimerService.send(ctx, TimerService.ACTION_HIDE_OVERLAY)
                            Settings.canDrawOverlays(ctx) -> {
                                needPermHint = false
                                TimerService.send(ctx, TimerService.ACTION_SHOW_OVERLAY)
                            }
                            else -> {
                                needPermHint = true
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${ctx.packageName}")
                                    )
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (s.overlayShown) "إخفاء النافذة العائمة" else "تشغيل النافذة العائمة") }
                if (needPermHint && !Settings.canDrawOverlays(ctx)) {
                    Text(
                        "فعّل \"العرض فوق التطبيقات الأخرى\" ثم ارجع واضغط الزر مرة أخرى",
                        fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
