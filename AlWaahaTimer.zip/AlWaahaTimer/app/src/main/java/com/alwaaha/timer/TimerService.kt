package com.alwaaha.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class TimerService : Service() {

    companion object {
        const val ACTION_START = "com.alwaaha.timer.START"
        const val ACTION_TOGGLE = "com.alwaaha.timer.TOGGLE"
        const val ACTION_RESET = "com.alwaaha.timer.RESET"
        const val ACTION_STOP_ALARM = "com.alwaaha.timer.STOP_ALARM"
        const val ACTION_SHOW_OVERLAY = "com.alwaaha.timer.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.alwaaha.timer.HIDE_OVERLAY"

        private const val CH_RUN = "timer_running"
        private const val CH_DONE = "timer_done"
        private const val RUN_ID = 1
        private const val DONE_ID = 2

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, TimerService::class.java).setAction(action)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager
    private lateinit var wm: WindowManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var ringtone: Ringtone? = null
    private var endTime = 0L
    private var lastKey = -1L

    private var overlay: View? = null
    private var overlayBg: GradientDrawable? = null
    private var timeView: TextView? = null
    private var playBtn: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!TimerState.running) return
            val left = endTime - SystemClock.elapsedRealtime()
            if (left <= 0) {
                TimerState.remainingMs = 0
                TimerState.running = false
                releaseWakeLock()
                startAlarm()
                refresh()
                return
            }
            TimerState.remainingMs = left
            refresh()
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_RUN, "المؤقت الجاري", NotificationManager.IMPORTANCE_LOW)
            )
            val done = NotificationChannel(CH_DONE, "انتهاء المؤقت", NotificationManager.IMPORTANCE_HIGH)
            done.setSound(null, null)       // الصوت يُشغَّل من الخدمة نفسها
            done.enableVibration(false)
            nm.createNotificationChannel(done)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        when (intent?.action) {
            ACTION_START, ACTION_TOGGLE -> toggle()
            ACTION_RESET -> reset()
            ACTION_STOP_ALARM -> stopAlarm()
            ACTION_SHOW_OVERLAY -> showOverlay()
            ACTION_HIDE_OVERLAY -> hideOverlay()
        }
        refresh()
        maybeStop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hideOverlay()
        ringtone?.stop(); ringtone = null
        releaseWakeLock()
        super.onDestroy()
    }

    // ---------- منطق المؤقت ----------

    private fun toggle() {
        when {
            TimerState.ringing -> stopAlarm()
            TimerState.running -> pause()
            else -> start()
        }
    }

    private fun start() {
        if (TimerState.remainingMs <= 0) TimerState.remainingMs = TimerState.totalSec * 1000
        endTime = SystemClock.elapsedRealtime() + TimerState.remainingMs
        TimerState.running = true
        acquireWakeLock(TimerState.remainingMs + 5000)
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun pause() {
        TimerState.running = false
        handler.removeCallbacks(tick)
        releaseWakeLock()
    }

    private fun reset() {
        pause()
        if (TimerState.ringing) stopAlarm()
        TimerState.remainingMs = TimerState.totalSec * 1000
    }

    private fun startAlarm() {
        TimerState.ringing = true
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val r = RingtoneManager.getRingtone(this, uri)
        r.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
        r.play()
        ringtone = r

        val v = vibrator()
        val pattern = longArrayOf(0, 600, 400)
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, 0))
        else @Suppress("DEPRECATION") v.vibrate(pattern, 0)

        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("انتهى الوقت")
            .setContentText("المؤقت وصل إلى صفر")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openAppIntent())
            .addAction(0, "إيقاف المنبّه", svc(ACTION_STOP_ALARM, 3))
            .setAutoCancel(true)
            .build()
        nm.notify(DONE_ID, n)
    }

    private fun stopAlarm() {
        ringtone?.stop(); ringtone = null
        vibrator().cancel()
        nm.cancel(DONE_ID)
        TimerState.ringing = false
        TimerState.remainingMs = TimerState.totalSec * 1000
    }

    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31)
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    private fun acquireWakeLock(ms: Long) {
        releaseWakeLock()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alwaaha:timer").apply { acquire(ms) }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun maybeStop() {
        if (!TimerState.running && !TimerState.ringing && overlay == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------- الإشعار ----------

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                RUN_ID, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else startForeground(RUN_ID, n)
    }

    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun svc(action: String, req: Int): PendingIntent {
        val i = Intent(this, TimerService::class.java).setAction(action)
        val f = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, req, i, f)
        else PendingIntent.getService(this, req, i, f)
    }

    private fun buildNotification(): Notification {
        val sec = (TimerState.remainingMs + 999) / 1000
        val b = NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
        if (TimerState.ringing) {
            b.setContentTitle("انتهى الوقت").setContentText("اضغط لإيقاف المنبّه")
                .addAction(0, "إيقاف المنبّه", svc(ACTION_STOP_ALARM, 3))
        } else {
            b.setContentTitle("مؤقت الواحة").setContentText(TimerState.fmt(sec))
                .addAction(0, if (TimerState.running) "إيقاف مؤقت" else "ابدأ", svc(ACTION_TOGGLE, 1))
                .addAction(0, "إعادة", svc(ACTION_RESET, 2))
        }
        return b.build()
    }

    /** يحدّث النافذة العائمة والإشعار. */
    private fun refresh() {
        val sec = (TimerState.remainingMs + 999) / 1000
        timeView?.text = if (TimerState.ringing) "انتهى!" else TimerState.fmt(sec)
        playBtn?.text = when {
            TimerState.ringing -> "⏹"
            TimerState.running -> "⏸"
            else -> "▶"
        }
        overlayBg?.setColor(if (TimerState.ringing) 0xE6C62828.toInt() else 0xE61B6B5A.toInt())

        val state = if (TimerState.ringing) 2L else if (TimerState.running) 1L else 0L
        val key = sec * 10 + state
        if (key != lastKey) {
            lastKey = key
            nm.notify(RUN_ID, buildNotification())
        }
    }

    // ---------- النافذة العائمة ----------

    private fun act(block: () -> Unit) {
        block(); refresh(); maybeStop()
    }

    private fun showOverlay() {
        if (overlay != null) return
        if (!Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val bg = GradientDrawable().apply {
            setColor(0xE61B6B5A.toInt()); cornerRadius = dp(18).toFloat()
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = bg
        }
        val time = TextView(this).apply {
            textSize = 30f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { onClick() }
        }
        val play = btn("▶") { act { toggle() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(play)
            addView(btn("↺") { act { reset() } })
            addView(btn("⤢") {
                startActivity(
                    Intent(this@TimerService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            })
            addView(btn("✕") { act { hideOverlay() } })
        }
        root.addView(time, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(row)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(120) }

        // سحب النافذة بالإصبع
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }

        try {
            wm.addView(root, lp)
            overlay = root; overlayBg = bg; timeView = time; playBtn = play
            TimerState.overlayShown = true
            lastKey = -1
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null; overlayBg = null; timeView = null; playBtn = null
        TimerState.overlayShown = false
    }
}
