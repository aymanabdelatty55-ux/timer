package com.alwaaha.timer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** حالة المؤقت المشتركة بين الشاشة والخدمة والنافذة العائمة. */
object TimerState {
    var totalSec by mutableLongStateOf(300L)
    var remainingMs by mutableLongStateOf(300_000L)
    var running by mutableStateOf(false)
    var ringing by mutableStateOf(false)
    var overlayShown by mutableStateOf(false)

    // إعدادات التنبيهات (تُحفظ في الجهاز)
    var beepEnabled by mutableStateOf(true)   // بيب في آخر 10 ثواني
    var warnEnabled by mutableStateOf(true)   // تنبيه قبل النهاية
    var warnMin by mutableIntStateOf(1)       // عدد الدقائق قبل النهاية

    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        beepEnabled = p.getBoolean("beep", true)
        warnEnabled = p.getBoolean("warn", true)
        warnMin = p.getInt("warnMin", 1)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putBoolean("beep", beepEnabled)
            .putBoolean("warn", warnEnabled)
            .putInt("warnMin", warnMin)
            .apply()
    }

    fun setTotal(sec: Long) {
        if (running || ringing) return
        val s = sec.coerceIn(5L, 359_999L)
        totalSec = s
        remainingMs = s * 1000
    }

    fun fmt(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
}
