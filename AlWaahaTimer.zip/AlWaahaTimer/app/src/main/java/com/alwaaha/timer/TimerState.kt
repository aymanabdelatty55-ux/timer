package com.alwaaha.timer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** حالة المؤقت المشتركة بين الشاشة والخدمة والنافذة العائمة. */
object TimerState {
    var totalSec by mutableLongStateOf(300L)
    var remainingMs by mutableLongStateOf(300_000L)
    var running by mutableStateOf(false)
    var ringing by mutableStateOf(false)
    var overlayShown by mutableStateOf(false)

    fun setTotal(sec: Long) {
        if (running || ringing) return
        val s = sec.coerceIn(5L, 359_999L)
        totalSec = s
        remainingMs = s * 1000
    }

    fun fmt(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
}
